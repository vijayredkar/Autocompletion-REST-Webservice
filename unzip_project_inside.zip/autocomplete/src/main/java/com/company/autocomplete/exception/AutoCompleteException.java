package com.company.autocomplete.exception;

public class AutoCompleteException extends Exception 
{
   public AutoCompleteException(String message) 
   {
	 super(message);  
   }

}
