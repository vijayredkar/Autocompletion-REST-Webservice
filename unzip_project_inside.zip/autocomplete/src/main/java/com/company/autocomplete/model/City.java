package com.company.autocomplete.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.springframework.stereotype.Component;
/*
 * POJO represents CITY table in DB 
 */
@Entity
public class City 
{
	@Id
	@GeneratedValue
	@Column(name="CITY_ID")
	private Long cityId;
	
	@Column(name="CITY_NAME")
	private String cityName;
	
	
	public Long getCityId() 
	{
		return cityId;
	}
	
	public void setCityId(Long cityId) 
	{
		this.cityId = cityId;
	}
	
	public String getCityName() 
	{
		return cityName;
	}
	
	public void setCityName(String cityName) 
	{
		this.cityName = cityName;
	}
}
