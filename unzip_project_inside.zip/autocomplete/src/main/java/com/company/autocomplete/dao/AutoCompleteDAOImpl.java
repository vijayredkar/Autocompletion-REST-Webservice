package com.company.autocomplete.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceUnit;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.company.autocomplete.exception.AutoCompleteException;
import com.company.autocomplete.model.City;

/*
 * DAO class for DB operations
 */
@Component
public class AutoCompleteDAOImpl implements AutoCompleteDAO
{
  Logger logger = LoggerFactory.getLogger(AutoCompleteDAOImpl.class);
  
  EntityManagerFactory emf;
  
  @PersistenceUnit
  public void setEmf(EntityManagerFactory emf)
  {
	 this.emf =  emf;
  }
  
  /*
   * API to query the DB and return cities that start with the text entered by the user   * 
   */
  public List<City> getCities(String startsWith, int maxRowsToDisplay) throws Exception
  {  
	  String searchClause = (startsWith+"%").toLowerCase();
	  String qryString = "from City where LOWER(cityName) LIKE :param";
	  	  
	  EntityManager em = emf.createEntityManager();
	  Query qryCitySearch = em.createQuery(qryString);
	  qryCitySearch.setParameter("param", searchClause);//binding parameter to mitigate SQL Injection attacks
	  
	  List<City> citiestList = qryCitySearch.setMaxResults(maxRowsToDisplay)
			  								.getResultList();
	  
	  if(citiestList == null || citiestList.size() == 0)
	  {
		 return null;
	  }	  	  
	  
	  return citiestList;
  }	
}