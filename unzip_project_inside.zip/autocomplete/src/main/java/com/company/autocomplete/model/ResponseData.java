package com.company.autocomplete.model;

/*
 * POJO to encapsulate response
 */
public class ResponseData 
{
 private String name;

	public String getName() 
	{
		return name;
	}

	public void setName(String name) 
	{
		this.name = name;
	} 
}
