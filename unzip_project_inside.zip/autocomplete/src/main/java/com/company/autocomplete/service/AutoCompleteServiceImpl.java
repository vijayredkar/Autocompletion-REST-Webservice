package com.company.autocomplete.service;

import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.company.autocomplete.constants.ProjectConstants;
import com.company.autocomplete.dao.AutoCompleteDAO;
import com.company.autocomplete.exception.AutoCompleteException;
import com.company.autocomplete.model.City;

@Service
public class AutoCompleteServiceImpl implements AutoCompleteService 
{
	@Autowired
	AutoCompleteDAO autoCompleteDAO;
	
	public List<City> getCities(String searchText, int maxRowsToDisplay) throws Exception
	{
		if(StringUtils.isEmpty(searchText) 								 || 
		   searchText.length() < ProjectConstants.MIN_LENGTH_SEARCH_TEXT || 
		   maxRowsToDisplay < 1)
		  {
			throw new AutoCompleteException("Error occured : Either entered searchText has less than " + ProjectConstants.MIN_LENGTH_SEARCH_TEXT + " chars or rows to display is be less than 1");  
		  }
		
		//initiate search only if the user has entered MIN_LENGTH_SEARCH_TEXT letters
		if(!StringUtils.isEmpty(searchText) && searchText.length() >= ProjectConstants.MIN_LENGTH_SEARCH_TEXT)
	    {   			 
			return autoCompleteDAO.getCities(searchText, maxRowsToDisplay);
	    }
		
		return null;//user's search text is either empty or less than the MIN_LENGTH_SEARCH_TEXT
	}
	
	/*
	 * method to build the collection of city data response 
	 * 
	 */
	public String prepareCityResponse(List citiesList) throws Exception
	{
		City city = new City();
		String responseData = "";
		
		Iterator<City> citiesListItr = citiesList.iterator();		
		while(citiesListItr.hasNext())
		{
		 city = citiesListItr.next();		 
		 responseData = responseData.concat(city.getCityName() + "\n");
		}//end while	
		
		return responseData;
	}

	public void setAutoCompleteDAO(AutoCompleteDAO autoCompleteDAO) {
		this.autoCompleteDAO = autoCompleteDAO;
	}
}