package com.company.autocomplete;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Bootstrapping application
 * On start up Hsqldb will be populated with cities data
 * which will be queried to suggest city names for auto completion
 *
 */

@SpringBootApplication
public class Application 
{
    public static void main( String[] args )
    {
    	SpringApplication.run(Application.class, args);
    }
}
