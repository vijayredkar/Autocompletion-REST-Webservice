package com.company.autocomplete.constants;

public class ProjectConstants 
{
 public static final Integer MIN_LENGTH_SEARCH_TEXT = 1;
}
