package com.company.autocomplete.service;

import java.util.List;

import com.company.autocomplete.dao.AutoCompleteDAO;

public interface AutoCompleteService 
{
	public List getCities(String searchText, int maxRowsToDisplay) throws Exception;
	public String prepareCityResponse(List citiesList) throws Exception;
	public void setAutoCompleteDAO(AutoCompleteDAO autoCompleteDAO);
}
