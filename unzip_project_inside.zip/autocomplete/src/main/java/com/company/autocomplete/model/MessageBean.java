package com.company.autocomplete.model;

public class MessageBean 
{  	
  private String message;
  
   public MessageBean() 
    {	
    }
  
	public MessageBean(String message) 
	{	
	  this.message = message;
	}

	public String getMessage() {
		return message;
	}
	
	public void setMessage(String message) {
		this.message = message;
	}

}
