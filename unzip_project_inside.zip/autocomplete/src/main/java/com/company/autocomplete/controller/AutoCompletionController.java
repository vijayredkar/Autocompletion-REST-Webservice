package com.company.autocomplete.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.company.autocomplete.exception.AutoCompleteException;
import com.company.autocomplete.model.City;
import com.company.autocomplete.service.AutoCompleteService;

@RestController
public class AutoCompletionController 
{
	@Autowired
	AutoCompleteService autoCompleteService;
	
	Logger logger = LoggerFactory.getLogger(AutoCompletionController.class);

	/*
	 * REST API to search city names that start with the text input by the user  
	 */
	//@CrossOrigin( origins = "http://localhost:3000")
	@RequestMapping(value = "/suggest_cities", 
					method = RequestMethod.GET,
					 produces = MediaType.TEXT_PLAIN_VALUE
					)	
	public ResponseEntity<String> search(@RequestParam("start") String searchText, 
										 @RequestParam("atmost") int maxRowsToDisplay) 
														    
	{	
		try 
		{
			logger.info("searchText is "+searchText + " and max rows to display is " +maxRowsToDisplay);
			List<City> citiesList = autoCompleteService.getCities(searchText, maxRowsToDisplay);
			
			//Return no content status if no results come out of the search operation. 
			if(citiesList == null || citiesList.size() ==0)
			{
			  logger.info("No cities were found that start with "+searchText);	
			  return new ResponseEntity<String>(HttpStatus.NO_CONTENT);
			}
			//prepare response data from the obtained search results
			String responseDataCollection = autoCompleteService.prepareCityResponse(citiesList);
			
			logger.info(responseDataCollection.length() + " cities were found for the user search that starts with "+searchText);
			return new ResponseEntity<String>(responseDataCollection, HttpStatus.OK);			
		}
		catch (AutoCompleteException e ) 
		{			
			e.printStackTrace();
		}
		catch (Exception e ) 
		{
			e.printStackTrace();
		}
		return new ResponseEntity<String>(HttpStatus.INTERNAL_SERVER_ERROR);
	}//end method
	
}//end class