package com.company.autocomplete.dao;

import java.util.List;

import com.company.autocomplete.exception.AutoCompleteException;
import com.company.autocomplete.model.City;


public interface AutoCompleteDAO 
{
	public List<City> getCities(String startsWith, int maxRowsToDisplay) throws Exception ;
}
