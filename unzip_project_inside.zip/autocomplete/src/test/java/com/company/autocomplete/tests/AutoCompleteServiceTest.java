package com.company.autocomplete.tests;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;

import com.company.autocomplete.dao.AutoCompleteDAO;
import com.company.autocomplete.model.City;
import com.company.autocomplete.service.AutoCompleteService;
import com.company.autocomplete.service.AutoCompleteServiceImpl;

public class AutoCompleteServiceTest 
{

@Mock	
AutoCompleteDAO autoCompleteDAO;

@Autowired
AutoCompleteService autoCompleteService;

 @Before
 public void setup()
 {
   MockitoAnnotations.initMocks(this);
 }
	
 @After
 public void tearDown()
 {
	  
 }
/*
 * Unit test for a valid search text	
 */
 @Test
 public void searchCitiesWithValidSearchTest() throws Exception
 { 
	 City city = new City();	 
	 List<City> listOfCities = new ArrayList<City>();
	 
	 city.setCityName("Ada B.O");
	 listOfCities.add(city);
	 city.setCityName("Andugulpet B.O");
	 listOfCities.add(city);
	 city.setCityName("Annaram B.O");
	 listOfCities.add(city);
	 
	 AutoCompleteService autoCompleteService = new AutoCompleteServiceImpl();
	 autoCompleteService.setAutoCompleteDAO(autoCompleteDAO);
	 
	 Mockito.when(autoCompleteDAO.getCities(Mockito.anyString(),Mockito.anyInt())).thenReturn(listOfCities);
	 Assert.assertEquals(autoCompleteService.getCities("a%", 3).size(), 3);	 
	 Mockito.verify(autoCompleteDAO,Mockito.times(1)).getCities(Mockito.anyString(), Mockito.anyInt());
 }
 
 /*
  * Unit test for a blank search text should return no results and mock is not invoked	
  */
	 @Test 
	 public void searchCitiesWithBlankInputTest() throws Exception 
	 { 
		 try 
		 {
			List<City> listOfCities = new ArrayList<City>();
			 
			 AutoCompleteService autoCompleteService = new AutoCompleteServiceImpl();		 
			 autoCompleteService.setAutoCompleteDAO(autoCompleteDAO);
			 
			 Mockito.when(autoCompleteDAO
					.getCities(Mockito.anyString(), Mockito.anyInt()))
			 		.thenReturn(listOfCities);
			 Assert.assertEquals(autoCompleteService.getCities("", 3),null);
			 //Mockito.verify(autoCompleteDAO, Mockito.times(0)).getCities(Mockito.anyString(), Mockito.anyInt());
		}
		 catch (Exception e) 
		 {
			e.printStackTrace();
		}
		 
		 Mockito.verify(autoCompleteDAO, Mockito.times(0)).getCities(Mockito.anyString(), Mockito.anyInt());
	 }
	
	 /*
	  * Unit test to test scenario when an exception is thrown
	  */
	 @Test
	 public void searchCitiesThrowsException() //vijay throw custom exception
	 {
		 List listOfCities = new ArrayList();
		 try 
		 {
			AutoCompleteService autoCompleteService = new AutoCompleteServiceImpl();
			autoCompleteService.setAutoCompleteDAO(autoCompleteDAO);
			  
			Mockito.doThrow(new RuntimeException("--------Exception thrown from getCities(Mockito.anyString(), Mockito.eq(negativeOne))"))
			 		.when(autoCompleteDAO)
			 		.getCities(Mockito.anyString(), Mockito.eq(new Integer(-1)));
			 
			listOfCities = autoCompleteService.getCities("a%", -1);
		}
		 catch (Exception e) 
		 {
			e.printStackTrace();
		 }
		 
		 Assert.assertEquals(listOfCities.size(), 0);
	 }
}