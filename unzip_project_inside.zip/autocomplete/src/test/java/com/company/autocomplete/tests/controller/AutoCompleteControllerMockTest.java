package com.company.autocomplete.tests.controller;

import java.util.ArrayList;
import java.util.List;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.company.autocomplete.controller.AutoCompletionController;
import com.company.autocomplete.model.City;
import com.company.autocomplete.service.AutoCompleteService;
import com.company.autocomplete.tests.AutoCompleteControllerTest;

public class AutoCompleteControllerMockTest extends AutoCompleteControllerTest
{	
	@Mock
	AutoCompleteService autoCompleteService;
	
	@InjectMocks
	private AutoCompletionController autoCompletionController;
	
  @Before	
  public void setUp()
  {
	  MockitoAnnotations.initMocks(this);
	  setUp(autoCompletionController);
  }
  
  @Test
  public void searchTest() throws Exception
  {
     String uri = "/suggest_cities?start=m&atmost=1";
     String response ="";
     
     List<City> listOfCities = new ArrayList<City>();
     City city = new City();
     city.setCityName("Maddikal B.O");
     listOfCities.add(city);
     
     Mockito.when(autoCompleteService.getCities(Mockito.anyString(), Mockito.anyInt()))
		  						     .thenReturn(listOfCities);
     
     Mockito.when(autoCompleteService.prepareCityResponse(Mockito.anyList()))
	     							 .thenReturn("Maddikal B.O");
     
      MvcResult mvcResult =  mockMvc.perform(MockMvcRequestBuilders
    		  				        .get(uri)
    							    .accept(MediaType.TEXT_PLAIN_VALUE))
    							    .andReturn();

      response = mvcResult.getResponse().getContentAsString();
      
	  Assert.assertTrue("Failure: searchTest- expected response but was empty ", response.trim().length() > 0);	  
	  Mockito.verify(autoCompleteService, Mockito.times(1)).getCities(Mockito.anyString(), Mockito.anyInt());
	  Mockito.verify(autoCompleteService, Mockito.times(1)).prepareCityResponse(Mockito.anyList());
  }	
}